# app/database.py
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()  # This is the ONLY instance
